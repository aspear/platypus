"""
Copyright (c) 2016,  VMware Inc., All Rights Reserved.

This file is open source software released under the terms of the
BSD 3-Clause license, https://opensource.org/licenses/BSD-3-Clause:

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors
 may be used to endorse or promote products derived from this software without
 specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

###############################################################################

This file is a utility meant for contributing samples to VMware Sample Exchange,
https://developercenter.vmware.com/samples
"""
from __future__ import ( division, absolute_import, print_function, unicode_literals )
import re
import urllib
import sys
import base64
import glob
import os
import string

from swagger_client.models.tag import Tag




import sys, os, tempfile, logging

if sys.version_info >= (3,):
    import urllib.request as urllib2
    import urllib.parse as urlparse
else:
    import urllib2
    import urlparse
#from swagger_client.models.category import Category


def stdout(lineString):
    sys.stdout.write(lineString)
    sys.stdout.write("\n")


def stderr(lineString):
    sys.stderr.write(lineString)
    sys.stderr.write("\n")

TAG_RE = re.compile(r'<[^>]+>')
WHITESPACE_RE = re.compile(r'[ \t\r\n]+')

def abbrev_readme(input_html):
    """
    remove all html from a description, consolidate whitespace, remove end of lines, and abbreviate at 100 chars.
    """
    if not input_html:
        return ""
    output = TAG_RE.sub('', input_html)
    output = WHITESPACE_RE.sub(' ', output)
    return (output[:100] + '..') if len(output) > 100 else output

tagCounter = 1

def appendTagsAndCategories(tags, categories, contribution):
    """
     Append any tags from the tags and categories lists to the given Contribution object
    :param tags: list of strings for tags.  can optionally have category and value separated by colon.
    :param categories: list of strings for category values.  Can optionally have type and version separated via colon.
    """
    global tagCounter
    # append any extra tags
    if tags:
        for tagString in tags:
            tagString = urllib.unquote(tagString).decode('utf8')

            newTag = Tag()
            newTag.id = tagCounter
            tagCounter = tagCounter + 1

            if not contribution.tags:
                contribution.tags = []

            colonIndex = tagString.find(':')
            if colonIndex != -1:
                category, tag = tagString.split(":")
                newTag.category = category
                newTag.name = tag
            else:
                newTag.category = "Tags"
                newTag.name = tagString

            # check that the tag is not already in the set
            alreadyIn = False
            for currentTag in contribution.tags:
                if (currentTag.name == newTag.name) and (currentTag.category == newTag.category):
                    alreadyIn = True

            if not alreadyIn:
                contribution.tags.append(newTag)

#      append any extra categories
#     if categories:
#         for value in categories:
#             value = urllib.unquote(value).decode('utf8')
#  
#             newCategory = Category()
#             newCategory.id = tagCounter
#             tagCounter = tagCounter + 1
#  
#             if not contribution.categories:
#                 contribution.categories = []
#  
#             colonIndex = value.find(':')
#             if colonIndex != -1:
#                 catType, version = value.split(":")
#                 newCategory.type = catType
#                 newCategory.version = version
#             else:
#                 newCategory.version = ""
#                 newCategory.type = value
#  
#              check that category is not already in the set
#             alreadyIn = False
#             for currentCategory in contribution.categories:
#                 if (currentCategory.type == newCategory.type) and (currentCategory.version == newCategory.version):
#                     alreadyIn = True
#  
#             if not alreadyIn:
#                 contribution.categories.append(newCategory)

def fixSampleTitle(name):
    name = string.capwords(name)
    name = name.replace("Vmware", "VMware");
    name = name.replace("Vcenter", "vCenter");
    name = name.replace("VCenter", "vCenter");
    name = name.replace("Vsphere", "vSphere");
    name = name.replace("VSphere", "vSphere");

    name = name.replace("Vcloud", "vCloud");
    name = name.replace("VCloud", "vCloud");
    name = name.replace("Vsan", "vSAN");
    name = name.replace("Vapp", "vApp");
    name = name.replace("VApp", "vApp");
    name = name.replace("VMotion", "vMotion");
    name = name.replace("Vmotion", "vMotion");
    name = name.replace("Vco", "vCO");
    name = name.replace("Vra", "vRA");
    name = name.replace("Vro", "vRO");
    name = name.replace("VSan", "vSAN");
    name = name.replace("VSAN", "vSAN");
    name = name.replace("vSANVM", "vSAN VM");
    name = name.replace("VApp", "vApp");
    name = name.replace("Esxi", "ESXi");
    name = name.replace("Vmdk", "VMDK");
    name = name.replace("Nsx", "NSX");
    name = name.replace("Vaai", "VAAI");
    name = name.replace("Vm ", "VM ");
    name = name.replace(" Vm", " VM");
    name = name.replace("VSphereAutoRestartManager", "vSphere Auto Restart Manager");
    name = name.replace("Getorphanedvms", "Get Orphaned VMs");
    name = name.replace("Getallvms", "Get All VMs");
    name = name.replace("Uuid", "UUID");
    name = name.replace(" Dc", " DC");
    name = name.replace("Ovf", "OVF");

    name = name.replace("Scsi", "SCSI");
    name = name.replace("Sata", "SATA");
    name = name.replace("Iso", "ISO");
    name = name.replace("Cpu", "CPU");
    name = name.replace("Crud", "CRUD");

    name = name.replace("Cls", "CLS");
    name = name.replace("Api", "API");
    name = name.replace("Sdk", "SDK");
    name = name.replace("Psc", "PSC");
    name = name.replace("Sso", "SSO");
    name = name.replace("Create Create", "Create");

    return name



def findFiles(directoryPath, globPattern, recursive, filePathList, verbose):
    '''
    For a given directory and glob pattern, scan for files that match the glob and
    append the full paths to the file to the filePathList.

    directoryPath: string path to scan in

    globPattern: string glob to search for, e.g. "*.java"

    recursive: if True, then we recurse into subdirectories looking for the files as well

    filePathList: output param, string list to append full paths to

    verbose: if True print the names of directories to stdout as we enter them
    '''
    for dirpath, dirnames, filenames in os.walk(directoryPath):
        if verbose:
            stdout("Scanning dir %s" % dirpath)
        # os.chdir(dirpath)
        globMatchingFiles = glob.glob1(dirpath, globPattern)
        for f in globMatchingFiles:
            filePathList.append(os.path.join(dirpath, f))
        if not recursive:
            while len(dirnames) > 0:
                dirnames.pop()
        #directoriesScanned.append(dirpath)

def download_file(url, desc=None, verbose=None):
    u = urllib2.urlopen(url)

    scheme, netloc, path, query, fragment = urlparse.urlsplit(url)
    filename = os.path.basename(path)
    if not filename:
        filename = 'downloaded.file'
    if desc:
        filename = os.path.join(desc, filename)

    with open(filename, 'wb') as f:
        meta = u.info()
        meta_func = meta.getheaders if hasattr(meta, 'getheaders') else meta.get_all
        meta_length = meta_func("Content-Length")
        file_size = None
        if meta_length:
            file_size = int(meta_length[0])
        print("    Downloading: {0} Bytes: {1}".format(url, file_size))

        file_size_dl = 0
        block_sz = 8192
        while True:
            buffer = u.read(block_sz)
            if not buffer:
                break

            file_size_dl += len(buffer)
            f.write(buffer)

            if verbose:
                status = "{0:16}".format(file_size_dl)
                if file_size:
                    status += "   [{0:6.2f}%]".format(file_size_dl * 100 / file_size)
                status += chr(13)
                print(status, end="")
        if verbose:
            print()

    return filename

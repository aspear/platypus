vra_file_to_api_uid_dict = {
    # vRA
	'api-vra-advanced-designer-service.json'       : 'api_vra_advanced_designer',
	'api-vra-approval-service.json'                : 'api_vra_approval',
	'api-vra-branding-service.json'                : 'api_vra_branding',
	'api-vra-catalog-service.json'                 : 'api_vra_catalog',
	'api-vra-component-registry.json'              : 'api_vra_component_registry',
	'api-vra-composition-service.json'             : 'api_vra_composition',
	'api-vra-config-management-service.json'       : 'api_vra_config_management',
	'api-vra-container-service.json'               : 'api_vra_container',
	'api-vra-content-management.json'              : 'api_vra_content_management',
	'api-vra-endpoint-configuration-service.json'  : 'api_vra_endpoint_configuration',
	'api-vra-event-broker-service.json'            : 'api_vra_event_broker',
	'api-vra-forms-service.json'                   : 'api_vra_forms',
	'api-vra-healthbroker-proxy-server.json'       : 'api_vra_healthbroker_proxy_server',
	'api-vra-iaas-proxy-provider.json'             : 'api_vra_iaas_proxy_provider',
	'api-vra-identity.json'                        : 'api_vra_identity',
	'api-vra-ipam-service.json'                    : 'api_vra_ipam',
	'api-vra-licensing-service.json'               : 'api_vra_licensing',
	'api-vra-management-service.json'              : 'api_vra_management',
	'api-vra-network-service.json'                 : 'api_vra_network',
	'api-vra-notification-service.json'            : 'api_vra_notification',
    'api-vra-o11n-gateway-service.json'            : 'api_vra_o11n_gateway',
	'api-vra-placement-service.json'               : 'api_vra_placement',
	'api-vra-plugin-service.json'                  : 'api_vra_plugin',
	'api-vra-portal-service.json'                  : 'api_vra_portal',
	'api-vra-properties-service.json'              : 'api_vra_properties',
	'api-vra-reservation-service.json'             : 'api_vra_reservation',
	'api-vra-software-service.json'                : 'api_vra_software',
	'api-vra-vco.json'                             : 'api_vro_rest',
	'api-vra-workitem-service.json'                : 'api_vra_workitem',
}

platypus_file_to_api_uid_dict = {
    #platypus
    'api-nsx-6.2.json' :   'api_nsx_for_vsphere',
    'api-photon.json' :    'api_photon_controller',
    'api-vra-7.json' :     'api_vrealize_automation',
    'api-vrli-3.3.json' :  'api_log_insight',
    'api-vro-7.json' :     'api_vrealize_orchestrator',
    'api-vrops-6.2.json' : 'api_vrealize_operations',   
}

def getApiUidForFileName( fileName ):
    api_uid = vra_file_to_api_uid_dict[ fileName ]
    if api_uid:
        return api_uid
    api_uid = platypus_file_to_api_uid_dict[ fileName ]
    return api_uid 

def getVraApiUidList():
    return vra_file_to_api_uid_dict.values()       

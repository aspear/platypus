webpackJsonp(["dev-center.module"],{

/***/ "./src/app/dev-center/dev-center.component.html":
/***/ (function(module, exports) {

module.exports = "<h1 *ngIf=\"config\">{{config.title}}</h1>\n\n<form [formGroup]=\"form\" *ngIf=\"config && config.showProductsList===true\">\n    <div class=\"form-group\">\n        <label>Product category</label>\n        <vmw-combobox\n                placeholder=\"Select a product\"\n                formControlName=\"productCategory\"\n                name=\"productCategory\"\n                [items]=\"items\"\n                filterItemsWhenTyping=\"false\"\n                filterIncludes=\"false\"\n                isAddNewAllowed=\"false\"\n                autoComplete=\"false\"\n                noItemsFoundString></vmw-combobox>\n    </div>\n    <div *ngIf=\"showDevCenterOverview == true\">\n            <h3>Overview</h3>\n            <p>\n                Select a product and see the product Developer Center.\n            </p>\n    </div>\n</form>\n\n<vmw-developer-center *ngIf=\"loading==0 && showDevCenter == true\">\n\n    <vmw-developer-center-overview-page *ngIf=\"overviewHtml\">\n        <div style=\"margin-top:15px;\" [innerHTML]=\"overviewHtml\"></div>\n    </vmw-developer-center-overview-page>\n\n    <vmw-developer-center-api-explorer-page *ngIf=\"apis && apis.length > 0\">\n        <div *ngFor=\"let api of apis\">\n\n            <vmw-developer-center-api *ngIf=\"api.type === 'SWAGGER'\"\n                [title]=\"api.name\"\n                [swaggerUrl]=\"api.url\"\n                [host]=\"host\"\n                [basePath]=\"basePath\"\n                [parameterMap]=\"paramMap\"\n                [headerMap]=\"headerMap\">\n            </vmw-developer-center-api>\n\n            <vmw-developer-center-api *ngIf=\"api.type === 'HTML'\"\n                [title]=\"api.name\"\n                [htmlUrl]=\"api.url\">\n            </vmw-developer-center-api>\n        </div>\n    </vmw-developer-center-api-explorer-page>\n\n    <vmw-developer-center-code-sample-page [platform]=\"platform\" *ngIf=\"platform\">\n        <p class=\"top\">\n            {{samplePageOverview}}\n            <a [href]=\"SAMPLE_EXCHANGE_URL\" target=\"_blank\">\n                    VMware&#123;code&#125; Sample Exchange\n                    <clr-icon shape=\"pop-out\" size=\"16\"></clr-icon>\n            </a>\n        </p>\n    </vmw-developer-center-code-sample-page>\n\n    <vmw-developer-center-sdks-page [productId]=\"productId\" [releaseId]=\"releaseId\">\n        <p class=\"top\">\n            {{sdkPageOverview}}\n        </p>\n    </vmw-developer-center-sdks-page>\n\n    <vmw-developer-center-docs-page [productId]=\"productId\" [releaseId]=\"releaseId\">\n        <p class=\"top\">\n\n        </p>\n    </vmw-developer-center-docs-page>\n\n    <!--\n    <vmw-developer-center-downloads-page>\n\n    </vmw-developer-center-downloads-page>\n    -->\n</vmw-developer-center>\n"

/***/ }),

/***/ "./src/app/dev-center/dev-center.component.scss":
/***/ (function(module, exports) {

module.exports = ".env-label {\n  font-size: 11px;\n  color: #565656;\n  padding-top: 16px;\n  padding-bottom: 4px;\n  display: block;\n  line-height: 11px; }\n\n::ng-deep .dark .env-label {\n  color: #FEFEFE; }\n\ninput {\n  width: 100%; }\n"

/***/ }),

/***/ "./src/app/dev-center/dev-center.component.ts":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
/*
 * Copyright (c) 2018 VMware, Inc. All Rights Reserved.
 */
var core_1 = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var forms_1 = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
var http_1 = __webpack_require__("./node_modules/@angular/common/esm5/http.js");
var router_1 = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
var ngx_components_1 = __webpack_require__("./node_modules/@vmw/ngx-components/esm5/vmw-ngx-components.js");
var auth_service_1 = __webpack_require__("./src/dev-center-auth/auth/auth.service.ts");
var ngx_dev_center_1 = __webpack_require__("./node_modules/@vmw/ngx-dev-center/esm5/vmw-ngx-dev-center.js");
var app_config_1 = __webpack_require__("./src/app/app.config.ts");
//const APIX_SWAGGER = "https://vdc-prod-repo-vip.vmware.com:8443/dcr/rest/swagger.json";
//const SAMPLE_EXCHANGE_SWAGGER = "https://vdc-prod-repo-vip.vmware.com:8443/sampleExchange/v1/swagger.json";
var VmwDeveloperCenterComponent = /** @class */ (function () {
    function VmwDeveloperCenterComponent(apixService, authService, http, router, configService) {
        this.apixService = apixService;
        this.authService = authService;
        this.http = http;
        this.router = router;
        this.configService = configService;
        this.SAMPLE_EXCHANGE_URL = 'https://code.vmware.com/samples';
        this.form = new forms_1.FormGroup({
            productCategory: new forms_1.FormControl(),
        });
        this.items = [];
        this.releaseIds = [];
        this.paramMap = new Map();
        this.headerMap = new Map();
        this.host = null;
        this.basePath = null;
        this.apis = null;
        this.platform = null;
        this.overviewHtml = null;
        this.showDevCenterOverview = false;
        this.showDevCenter = false;
        this.loading = 0;
        this.defaultItem = new ngx_components_1.VmwComboboxItem("Select a product", "default");
    }
    VmwDeveloperCenterComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.form.get('productCategory').setValue(this.defaultItem);
        //read the config json file
        this.configService.getDevCenterConfigJSON().subscribe(function (data) {
            _this.config = data;
            _this.host = _this.config.host;
            _this.basePath = _this.config.basePath;
            if (_this.config.showProductsList) {
                _this.items = [
                    _this.defaultItem
                ];
                _this.form.get('productCategory').valueChanges.subscribe(function (newValue) {
                    //FIXME: the vmwcombobox creates new item if the filtered item does not exist causing APIs to return 404
                    if (_this.releaseIds.indexOf(newValue.value) == -1) {
                        console.log("no matching release id");
                        return;
                    }
                    if (newValue.value === 'default') {
                        _this.showDevCenter = false;
                        _this.showDevCenterOverview = true;
                    }
                    else {
                        _this.releaseId = newValue.value;
                        _this.platform = newValue.displayValue;
                        //console.log('release=' + this.releaseId + ', platform=' + this.platform);
                        _this.getApis();
                        _this.showDevCenter = true;
                        _this.showDevCenterOverview = false;
                    }
                });
            }
            else {
                _this.showDevCenter = true;
                _this.showDevCenterOverview = false;
                _this.platform = _this.config.platform;
                _this.productId = _this.config.productId;
                _this.releaseId = _this.config.releaseId;
                // SDKs page overview on the top
                _this.sdkPageOverview = _this.config.sdkPageOverview;
                // Samples page overview on the top
                _this.samplePageOverview = _this.config.samplePageOverview;
            }
            if (_this.config && _this.config.showProductsList === true) {
                _this.getProducts();
            }
            if (_this.showDevCenter) {
                // Overview
                var overviewPath = _this.config.overviewPath;
                if (overviewPath) {
                    _this.getOverview(overviewPath);
                }
                _this.getApis();
            }
        });
        this.authSubscription = this.authService.authChanged.subscribe(function (data) {
            var headerArray = sessionStorage.getItem('apix-header');
            var headers = headerArray ? JSON.parse(headerArray) : [];
            for (var _i = 0, headers_1 = headers; _i < headers_1.length; _i++) {
                var header = headers_1[_i];
                _this.headerMap.set(header.name, header.value);
            }
        });
    };
    VmwDeveloperCenterComponent.prototype.ngOnDestroy = function () {
        this.authSubscription.unsubscribe();
    };
    /* Get dev-center APIs */
    VmwDeveloperCenterComponent.prototype.getApis = function () {
        var _this = this;
        if (this.config.enableRemote === true) {
            // get remote APIs
            this.getRemoteApis(this.releaseId);
        }
        else {
            this.loading++;
            this.http.get(this.config.localApiUrl)
                .subscribe(function (apis) {
                _this.apis = apis;
                _this.loading--;
            }, function (error) { return _this.error = error; });
        }
    };
    /* Get dev-center overview */
    VmwDeveloperCenterComponent.prototype.getOverview = function (overviewPath) {
        var _this = this;
        this.loading++;
        if (overviewPath) {
            this.http.get(overviewPath, { responseType: 'text' })
                .subscribe(function (res) {
                _this.overviewHtml = res;
                _this.loading--;
            }, function (error) { return _this.error = error; });
        }
        else {
            // get overview from remote. Use API_OVERVIEW for the dev center overview?
        }
    };
    /* Get remote APIs from the given releaseId */
    VmwDeveloperCenterComponent.prototype.getRemoteApis = function (releaseId) {
        var _this = this;
        this.loading++;
        this.apixService.getApisByRelease(releaseId)
            .subscribe(function (apis) {
            _this.loading--;
            var result = [];
            for (var _i = 0, apis_1 = apis; _i < apis_1.length; _i++) {
                var api = apis_1[_i];
                if (api.name != null && api.api_ref_doc_url != null) {
                    var type = api.api_ref_doc_type;
                    if (type === 'DOC_CENTER' || type === 'IFRAME') {
                        type = 'HTML';
                    }
                    result.push({
                        "name": api.name,
                        "url": api.api_ref_doc_url,
                        "type": type
                    });
                }
            }
            _this.apis = result;
            //console.log(this.apis);
        }, function (error) {
            _this.apis = [];
            _this.error = error;
        });
    };
    /* Get products from code.vmware.com */
    VmwDeveloperCenterComponent.prototype.getProducts = function () {
        var _this = this;
        this.loading++;
        this.apixService.getProducts()
            .subscribe(function (products) {
            _this.loading--;
            _this.products = products;
            //console.log(this.products);
            // find the latest release
            for (var _i = 0, products_1 = products; _i < products_1.length; _i++) {
                var product = products_1[_i];
                var releases = product.releases;
                releases.sort(function (a, b) {
                    var dataA = new Date(a.release_date);
                    var dateB = new Date(b.release_date);
                    if (dataA > dateB)
                        return -1;
                    if (dataA < dateB)
                        return 1;
                    return 0;
                });
                for (var _a = 0, releases_1 = releases; _a < releases_1.length; _a++) {
                    var release = releases_1[_a];
                    _this.items.push(new ngx_components_1.VmwComboboxItem(product.name + " " + release.version, release.id));
                    _this.releaseIds.push(release.id);
                }
            }
        }, function (error) {
            _this.products = [];
        });
    };
    VmwDeveloperCenterComponent = __decorate([
        core_1.Component({
            template: __webpack_require__("./src/app/dev-center/dev-center.component.html"),
            styles: [__webpack_require__("./src/app/dev-center/dev-center.component.scss")],
        }),
        __metadata("design:paramtypes", [ngx_dev_center_1.VmwAPIXService,
            auth_service_1.DevCenterAuthService,
            http_1.HttpClient,
            router_1.Router,
            app_config_1.AppConfigService])
    ], VmwDeveloperCenterComponent);
    return VmwDeveloperCenterComponent;
}());
exports.VmwDeveloperCenterComponent = VmwDeveloperCenterComponent;


/***/ }),

/***/ "./src/app/dev-center/dev-center.module.ts":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/*
 * Copyright (c) 2018 VMware, Inc. All Rights Reserved.
 */
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = __webpack_require__("./node_modules/@angular/core/esm5/core.js");
var forms_1 = __webpack_require__("./node_modules/@angular/forms/esm5/forms.js");
var router_1 = __webpack_require__("./node_modules/@angular/router/esm5/router.js");
var common_1 = __webpack_require__("./node_modules/@angular/common/esm5/common.js");
var angular_1 = __webpack_require__("./node_modules/@clr/angular/esm5/clr-angular.js");
var ngx_components_1 = __webpack_require__("./node_modules/@vmw/ngx-components/esm5/vmw-ngx-components.js");
var ngx_dev_center_1 = __webpack_require__("./node_modules/@vmw/ngx-dev-center/esm5/vmw-ngx-dev-center.js");
var dev_center_component_1 = __webpack_require__("./src/app/dev-center/dev-center.component.ts");
var VmwDeveloperCenterModule = /** @class */ (function () {
    function VmwDeveloperCenterModule() {
    }
    VmwDeveloperCenterModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                forms_1.ReactiveFormsModule,
                angular_1.ClarityModule,
                router_1.RouterModule.forChild([{
                        path: "**",
                        component: dev_center_component_1.VmwDeveloperCenterComponent,
                    }]),
                ngx_dev_center_1.VmwDevCenterModule.forRoot(),
                ngx_components_1.VmwComponentsModule.forRoot(),
            ],
            declarations: [
                dev_center_component_1.VmwDeveloperCenterComponent,
            ],
        })
    ], VmwDeveloperCenterModule);
    return VmwDeveloperCenterModule;
}());
exports.VmwDeveloperCenterModule = VmwDeveloperCenterModule;


/***/ })

});
//# sourceMappingURL=dev-center.module.chunk.js.map